
package ListaHerancaEx1;


public class FuncionarioMensalista extends Funcionario {
    
 private int numeroCracha;
 private String nome;
 private String setor;
 private String funcao;
 private Double salario;
    
 
   // metodo construtor PADRAO
   public FuncionarioMensalista(){ 
   }

    public FuncionarioMensalista(String nome, String setor,
            String funcao, int numeroCracha,Double salario){ 
        this.nome=nome;
        this.setor=setor;
        this.funcao=funcao;
        this.numeroCracha=numeroCracha;
        this.salario=salario;
    }
          public String imprimir(){
                 return "Nome : " + getNome() +
                 "\nSetor :" + getSetor()+
                 "\nFuncao :" + getFuncao()+
                 "\nNumero do Cracha :" + getNumeroCracha();
                    
 
          }

    /**
     * @return the numeroCracha
     */
    public int getNumeroCracha() {
        return numeroCracha;
    }

    /**
     * @param numeroCracha the numeroCracha to set
     */
    public void setNumeroCracha(int numeroCracha) {
        this.numeroCracha = numeroCracha;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the setor
     */
    public String getSetor() {
        return setor;
    }

    /**
     * @param setor the setor to set
     */
    public void setSetor(String setor) {
        this.setor = setor;
    }

    /**
     * @return the funcao
     */
    public String getFuncao() {
        return funcao;
    }

    /**
     * @param funcao the funcao to set
     */
    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }

    /**
     * @return the salario
     */
    public Double getSalario() {
        return salario;
    }

    /**
     * @param salario the salario to set
     */
    public void setSalario(Double salario) {
        this.salario = salario;
    }
    }

