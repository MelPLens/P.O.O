
package ListaHerancaEx1;


public class Funcionario {
    
//lista 04/04/2023 
// Mel plens RA: 22873


 private int numeroCracha;
 private String nome;
 private String setor;
 private String funcao;
    
 
   // metodo construtor PADRAO
   public Funcionario(){ 
   }

    public Funcionario(String nome, String setor,String funcao, int numeroCracha){ //METODO COM 2 PARAMETROS
        this.nome=nome;
        this.setor=setor;
        this.funcao=funcao;
        this.numeroCracha=numeroCracha;
    }

    
    public int getNumeroCracha() {
        return numeroCracha;
    }

   
    public void setNumeroCracha(int numeroCracha) {
        this.numeroCracha = numeroCracha;
    }

   
    public String getNome() {
        return nome;
    }

    
    public void setNome(String nome) {
        this.nome = nome;
    }

   
    public String getSetor() {
        return setor;
    }

   
    public void setSetor(String setor) {
        this.setor = setor;
    }

    public String getFuncao() {
        return funcao;
    }

  
    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }

    


}
