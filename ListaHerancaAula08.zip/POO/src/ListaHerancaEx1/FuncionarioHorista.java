
package ListaHerancaEx1;


public class FuncionarioHorista extends Funcionario {
     private int numeroCracha;
 private String nome;
 private String setor;
 private String funcao;
 private Double valorHora;
 private int qtdeHoras;
    
 
   // metodo construtor PADRAO
   public FuncionarioHorista(){ 
   }

    public FuncionarioHorista(String nome, String setor,
            String funcao, int numeroCracha,Double valorHora,int qtdeHoras){ 
        this.nome=nome;
        this.setor=setor;
        this.funcao=funcao;
        this.numeroCracha=numeroCracha;
        this.valorHora=valorHora;
        this.qtdeHoras=qtdeHoras;
    }
    
    
    
          public String imprimir(){
                 return "Nome : " + getNome() +
                 "\nSetor :" + getSetor()+
                 "\nFuncao :" + getFuncao()+
                 "\nNumero do Cracha :" + getNumeroCracha();
                    
 
          }

    /**
     * @return the numeroCracha
     */
    public int getNumeroCracha() {
        return numeroCracha;
    }

    /**
     * @param numeroCracha the numeroCracha to set
     */
    public void setNumeroCracha(int numeroCracha) {
        this.numeroCracha = numeroCracha;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the setor
     */
    public String getSetor() {
        return setor;
    }

    /**
     * @param setor the setor to set
     */
    public void setSetor(String setor) {
        this.setor = setor;
    }

    /**
     * @return the funcao
     */
    public String getFuncao() {
        return funcao;
    }

    /**
     * @param funcao the funcao to set
     */
    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }

    /**
     * @return the valorHora
     */
    public Double getValorHora() {
        return valorHora;
    }

    /**
     * @param valorHora the valorHora to set
     */
    public void setValorHora(Double valorHora) {
        this.valorHora = valorHora;
    }

    /**
     * @return the qtdeHoras
     */
    public int getQtdeHoras() {
        return qtdeHoras;
    }

    /**
     * @param qtdeHoras the qtdeHoras to set
     */
    public void setQtdeHoras(int qtdeHoras) {
        this.qtdeHoras = qtdeHoras;
    }
    }



