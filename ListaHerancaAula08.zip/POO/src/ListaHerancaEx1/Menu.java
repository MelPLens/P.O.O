
package ListaHerancaEx1;

import java.util.ArrayList;
import java.util.Scanner;

public class Menu extends Funcionario {
 private ArrayList<Funcionario> funcionarios = new ArrayList<>();
               public void adicionar(Funcionario funcionario) {
        this.funcionarios.add(funcionario);     
    }
    public static void main(String[] args) {
 
      
        Scanner input = new Scanner(System.in);
        int opcao = 0;
        
        // Instanciando um objeto da classe 
        Menu m = new Menu();
        
        do {
            System.out.println("\nMENU:");
            System.out.println("1 - Inserir Funcionario");
            System.out.println("2 - Exibir Funcionario");
            System.out.println("3 - Sair");
            System.out.print("Digite a opção desejada: ");
            opcao = input.nextInt();
            
            switch(opcao) {
                case 1:
                    // Chamando o set nome de funcionario.
                    Menu.setNome();
                    break;
                case 2:
                    // Chamando o método inserirProfessor() da classe Sistema
                    Menu.setNumeroCracha();
                    break;      
                case 3:
                    System.out.println("Saindo do sistema...");
                    break;
                default:
                    System.out.println("Opção inválida! Tente novamente.");
                    break;
            }
            
        } while(opcao != 3);
        
        input.close();
    }

    private static void setNome() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private static void setNumeroCracha() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

 
    }
    
      


    
    
