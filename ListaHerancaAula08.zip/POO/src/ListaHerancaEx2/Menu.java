
package ListaHerancaEx2;

import ListaHerancaEx1.Funcionario;
import java.util.ArrayList;
import java.util.Scanner;


public class Menu extends Imovel {

   

  
private ArrayList<Imovel> imoveis = new ArrayList<>();
public void adicionar(Imovel imoveis) {
        this.imoveis.add(imoveis); 
               }
               
               
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int opcao = 0;
        
       
        Menu i = new Menu();
        
        do {
            System.out.println("\nMENU:");
            System.out.println("1 - Inserir Imovel");
            System.out.println("2 - Exibir Imoveis");
            System.out.println("3 - Sair");
            System.out.print("Digite a opção desejada: ");
            opcao = input.nextInt();
            
            switch(opcao) {
                case 1:
                    System.out.println("Novo ou Velho ?");
                    Menu.setcodigo();
                    break;
                case 2:
               
                    Menu.setendereco();
                    break;      
                case 3:
                    System.out.println("Saindo do sistema...");
                    break;
                default:
                    System.out.println("Opção inválida! Tente novamente.");
                    break;
            }
            
        } while(opcao != 3);
        
        input.close();
    }
 

    private static void setendereco() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    private static void setcodigo() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
 
    }
    
    

