
package ListaHerancaEx2;

public class Imovel {
    
 private int codigo;
 private String endereco;
 private Double valor;
 
    
 
   // metodo construtor PADRAO
   public Imovel(){ 
   }

    public Imovel(String endereco, int codigo, Double valor){ 
        this.endereco=endereco;
        this.codigo=codigo;
        this.valor=valor;
   
    }

    /**
     * @return the codigo
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * @param codigo the codigo to set
     */
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    /**
     * @return the endereco
     */
    public String getEndereco() {
        return endereco;
    }

    /**
     * @param endereco the endereco to set
     */
    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    /**
     * @return the valor
     */
    public Double getValor() {
        return valor;
    }

    /**
     * @param valor the valor to set
     */
    public void setValor(Double valor) {
        this.valor = valor;
    }

}
