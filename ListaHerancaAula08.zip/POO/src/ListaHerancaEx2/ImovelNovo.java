
package ListaHerancaEx2;


public class ImovelNovo extends Imovel{
    
 private Double valorAdicional;


   // metodo construtor PADRAO
   public ImovelNovo(){ 
   }

    public ImovelNovo(String endereco, int codigo, Double valorAdicional) {
        super(endereco, codigo, valorAdicional);
    }

    
    public Double getValorAdicional() {
        return valorAdicional;
    }

    /**
     * @param valorAdicional the valorAdicional to set
     */
    public void setValorAdicional(Double valorAdicional) {
        this.valorAdicional = valorAdicional;
    }
    
    public double calcularValorImovel(double valorAdicional) {
        this.valorAdicional += this.valorAdicional * valorAdicional;
     return 0;
    }
    
   public String imprimir(){
                 return "Nome : " + getendereco() +
                 "\nSetor :" + getcodigo()+
                 "\nValor :" + getValorAdicional();
                    
 
          }

    private String getendereco() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private String getcodigo() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
