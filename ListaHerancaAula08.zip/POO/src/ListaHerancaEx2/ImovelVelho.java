
package ListaHerancaEx2;


public class ImovelVelho extends Imovel {
    private Double valorDesconto;


   // metodo construtor PADRAO
   public ImovelVelho(){ 
   }

    public ImovelVelho(String endereco, int codigo, Double valorDesconto) {
        super(endereco, codigo, valorDesconto);
    }

      public double calcularValorImovel(double valorAdicional) {
        this.valorDesconto += this.valorDesconto- valorAdicional;
     return 0;
    }
   
    
   public String imprimir(){
                 return "Nome : " + getendereco() +
                 "\nSetor :" + getcodigo()+
                 "\nValor :" + getValorDesconto();
                    
 
          }

    private String getendereco() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private String getcodigo() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    
    public Double getValorDesconto() {
        return valorDesconto;
    }


    public void setValorDesconto(Double valorDesconto) {
        this.valorDesconto = valorDesconto;
    }

}

