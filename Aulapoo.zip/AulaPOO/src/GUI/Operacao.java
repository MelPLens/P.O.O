
package GUI;

//+ somar(num1 : double, num2: double) : double
//+ subtrair(num1 : double, num2: double) : double
//+ dividir(num1 : double, num2: double) : double
//+ multiplicar(num1 : double, num2: double) : double

public class Operacao {
    
}
