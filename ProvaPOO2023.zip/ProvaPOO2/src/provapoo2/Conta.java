
package provapoo2;
//a.	Definir quais são atributos privados e quais são protegidos, conforme imagem.ok
//b.	Criar um método construtor que recebe: saldo, limite.


public class Conta {
    
    protected double saldo;
    private double limite;
    
   public Conta(double saldo, double limite) { // construtor
        this.saldo = saldo;
        this.limite = limite;
    }
///c.	Implementar o método deposita, que deve adicionar 
//o valor passado ao saldo da conta já existente.
    public void deposita(double valor) {
        this.saldo += valor;
    }
    
    
    
//d.	Implementar o método sacar que deve retirar 
//o valor do saldo somente quando 
//o valor passado for menor que a soma do (saldo + limite) da conta e retornar a mensagem “OK” 
//quando o valor for sacado e “Valor indisponível” quando não for possível realizar o saque.
    public String sacar(double valor) {
        if (valor <= this.saldo + this.limite) {
            this.saldo -= valor;
            return "OK";
        } else {
            return "Valor indisponível";
        }
    }
    
    
//e.	Implementar o método transferir, que deve sacar o dinheiro da conta atual e 
//depositar o dinheiro na conta passada como parâmetro. Retorne a mensagem “OK”, 
//caso a transferência tenha sido realizada com sucesso.
    public String transferir(double valor, Conta contaDestino) {
        String resultado = this.sacar(valor);
        if (resultado.equals("OK")) {
            contaDestino.deposita(valor);
            return "OK";
        } else {
            return resultado;
        }
    }
//f.	Criar o método atualiza que recebe uma taxa e atualiza essa conta de acordo com a taxa fornecida,
//onde no saldo é adicionado essa taxa. (fórmula: saldo = saldo + (saldo * taxa))
    public void atualiza(double taxa) {
        this.saldo += this.saldo * taxa;
    }
}
    
    

