/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package provapoo2;
 import java.util.ArrayList;
import java.util.List;
//a.	Implementar o método cadastrarCliente que recebe um cliente e insere na lista de clientes da agência.
//b.	Implementar o método cadastrarFuncionario que recebe um funcionário e insere na lista de funcionários da agência.


public class Agencia extends Pessoa {
   
    private String nome;
    private String endereco;
    private List<Cliente> clientes;
    private List<Funcionario> funcionarios;

    public Agencia() {
        clientes = new ArrayList<>();
        funcionarios = new ArrayList<>();
    }

    public void cadastrarCliente(Cliente cliente) {
        getClientes().add(cliente);
    }

    public void cadastrarFuncionario(Funcionario funcionario) {
        getFuncionarios().add(funcionario);
    }
//c.	Criar o método valorTotalAgencia que retorna a soma do saldo de todas as contas dos clientes da agência.
    public double valorTotalAgencia() {
        double valorTotal = 0;
        for (Cliente cliente : getClientes()) {
           this.clientes = getsaldo for (Conta conta : cliente.getContas()) {
                valorTotal += conta.getsaldo();
            }
        }
        return valorTotal;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the endereco
     */
    public String getEndereco() {
        return endereco;
    }

    /**
     * @param endereco the endereco to set
     */
    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    /**
     * @return the clientes
     */
    public List<Cliente> getClientes() {
        return clientes;
    }

    /**
     * @param clientes the clientes to set
     */
    public void setClientes(List<Cliente> clientes) {
        this.clientes = clientes;
    }

    /**
     * @return the funcionarios
     */
    public List<Funcionario> getFuncionarios() {
        return funcionarios;
    }

    /**
     * @param funcionarios the funcionarios to set
     */
    public void setFuncionarios(List<Funcionario> funcionarios) {
        this.funcionarios = funcionarios;
    }
}

