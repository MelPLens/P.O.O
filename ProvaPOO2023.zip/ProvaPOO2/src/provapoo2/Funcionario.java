
package provapoo2;
 import java.util.Random;
//Criar a classe Funcionario conforme imagem.
//a.Funcionário é um tipo de Pessoa. ok
//b.Os atributos são privados ok
//os métodos públicos (conforme imagem)ok

public class  Funcionario extends Pessoa {
    
    private int chapa;
    private double salario;
    
    Random gerador= new Random();

    //c.O método construtor da classe deve criar um número randômico de 0 a 1000 para o atributo chapa.

     public Funcionario(){ // metodo construtor // cuidado com parametros
         this.chapa=chapa;
         this.salario=salario;
         chapa= gerador.nextInt(0,1000);//numero randomico
    
     }
    public int getChapa() {
        return chapa;
    }

    /**
     * @param chapa the chapa to set
     */
    public void setChapa(int chapa) {
        this.chapa = chapa;
    }

    /**
     * @return the salario
     */
    public double getSalario() {
        return salario;
    }

   
    
    public void setSalario(double salario) {
        this.salario = salario;
    }
    
    
    //metodos public
    
    public void setchapa(int chapa) {
        this.chapa = chapa;
    }
   
    
    //O método setSalario só atribui valor ao atributo salário se o valor for maior que zero.
    public void setsalario(double salario, int setsalario) {
       
        if (setsalario>0){
            this.salario = salario;
        };
    }
    
    
    
    //e.Todo fim de ano o funcionário do banco tem um acréscimo de 10% de bonificação 
    //no salário, e para isso desenvolva o método setBonificacao na classe.
     public void setBonificacao() {
        this.salario = this.salario + (salario * 10)/100;
 
    }
    
    
}

