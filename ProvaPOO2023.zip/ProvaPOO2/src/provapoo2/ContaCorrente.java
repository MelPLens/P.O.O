
package provapoo2;

//a.	ContaCorrente é um tipo de Conta. ok

    public class ContaCorrente extends Conta {
        
        
    private static final double Taxabancaria = 0.10;
    
    public ContaCorrente(double saldo, double limite) {
        super(saldo, limite);
    }
    
    //b.	Deve sobrescrever o método “deposita”, onde todo depósito bancário de 
//uma conta corrente deve descontar a taxa bancária de 10 centavos.
    @Override
    public void deposita(double valor) {
        super.deposita(valor - Taxabancaria);
    }
    
    
    //c.	Deve sobrescrever o método “atualiza”, onde o valor atualizado 
//é o dobro da taxa passada (seguir a fórmula da questão 5.f, levando em consideração que a taxa é em dobro).
    @Override
    public void atualiza(double taxa) {
        super.atualiza(taxa * 2);
    }
}

