
package provapoo2;

//Crie uma interface chamada “ContaDeBanco”, que deve conter os métodos: 
//deposita, sacar e transferir, conforme imagem.
public interface ContadeBancoInterface {
    
    public void deposita(double valor);
    public void sacar(double valor);
    public void transferir(ContaDeBanco contaDestino, double valor);
   
}
    

