
package provapoo2;

//a.Gerente é um tipo de funcionário. ok 

import java.awt.Component;

public class Gerente extends Funcionario{
    
    private String senha;
    

//b.Criar um método cadastrarSenha que recebe uma string alfa-numérica e 
//retorna a mensagem “senha cadastrada com sucesso” 
//caso a senha seja maior que 5 caracteres 
//ou a mensagem “Senha deve conter no mínimo 5 caracteres” 
//(só atribuir o valor ao atributo senha se satisfazer a condição).
    
    public void cadastrarSenha() {
     if (
    private Component parentComponent;
senha.length() < 5) {
            return "Senha deve conter no mínimo 5 caracteres";
        } else {
            this.senha = senha;
            return "Senha cadastrada com sucesso";
}
        
 //c.Criar um método autentica que verifica 
//se a senha recebida é igual a senha do atributo,
//retorna true caso a senha seja a mesma e false caso a senha seja diferente.
      public boolean autentica(String senha) {
        return senha.equals(this.senha);
    }
      //d.Sobrescreva o método setBonificacao para quando executado 
//recebe um acréscimo de 20% de bonificação no salário.

      public void setBonificacao() {
        this.salario = this.salario + (salario * 20)/100;
 
    }
     }


