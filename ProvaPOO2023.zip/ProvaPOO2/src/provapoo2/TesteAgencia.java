
package provapoo2;

//a.	Criar o método main e realizar o teste do método “valorTotalAgencia” 
//da classe Agencia e para tal, crie os objetos necessários.
public class TesteAgencia {
  

    public static void main(String[] args) {
        Agencia agencia = new Agencia();
        
        // Criando clientes
        Cliente cliente1 = new Cliente("João", "111.111.111-11", "Rua A, 123");
        Cliente cliente2 = new Cliente("Maria", "222.222.222-22", "Rua B, 456");
        
        // Cadastrando clientes na agência
        agencia.cadastrarCliente(cliente1);
        agencia.cadastrarCliente(cliente2);
        
        // Criando contas correntes para os clientes
        ContaCorrente contaCorrente1 = new ContaCorrente(1000.0, 500.0);
        ContaCorrente contaCorrente2 = new ContaCorrente(2000.0, 1000.0);
        
        // Vinculando as contas correntes aos clientes
        cliente1.setConta(contaCorrente1);
        cliente2.setConta(contaCorrente2);
        
        // Criando contas poupanças para os clientes
        ContaPoupanca contaPoupanca1 = new ContaPoupanca(500.0);
        ContaPoupanca contaPoupanca2 = new ContaPoupanca(1000.0);
        
        // Vinculando as contas poupanças aos clientes
        cliente1.setConta(contaPoupanca1);
        cliente2.setConta(contaPoupanca2);
        
        // Calculando o valor total das contas dos clientes da agência
        double valorTotal = agencia.valorTotalAgencia();
        System.out.println("Valor total das contas dos clientes: " + valorTotal);
    }
}
}
