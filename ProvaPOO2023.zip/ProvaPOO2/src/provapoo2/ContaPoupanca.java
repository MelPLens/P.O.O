/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package provapoo2;

//a.	ContaPoupanca é um tipo de Conta.
//b.	Deve sobrescrever o método “atualiza”,
//onde o valor atualizado é o triplo da taxa passada 
//(seguir a fórmula da questão 5.f, levando em consideração que a taxa é o triplo agora).


    public class ContaPoupanca extends Conta {

    public ContaPoupanca(double par) {
    }

    @Override
    public void atualiza(double taxa) {
        double saldoAtualizado = getSaldo() + (getSaldo() * (3 * taxa));
        setSaldo(saldoAtualizado);
    }

}

