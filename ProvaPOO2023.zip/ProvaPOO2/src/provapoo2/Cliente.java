
package provapoo2;
import java.util.ArrayList;
import java.util.List;

//a.	Cliente é um tipo de Pessoa.ok
    
public class Cliente extends Pessoa {
    private List<Conta> contas;
    
    public Cliente(String nome, String cpf, String rua_A_123) {
    this.contas = new ArrayList<>();
    }
    
    
    //b.	Criar o método setConta que recebe um objeto conta e adiciona na lista de contas do cliente.
    public void setConta(Conta conta) {
        this.contas.add(conta);
    }
    
    
    //c.	Criar o método cadastrarConta, conforme imagem que 
    //recebe como parâmetros saldo e limite, para criar a conta e vincular à conta ao cliente.
    public void cadastrarConta(double saldo, double limite) {
        Conta conta = new Conta(saldo, limite);
        this.setConta(conta);
    }
}


